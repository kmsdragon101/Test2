from __future__ import unicode_literals

import logging

import ubus
from ubus import ffi, lib

class Session(object):
    def __init__(self, socket=None):
        pass
